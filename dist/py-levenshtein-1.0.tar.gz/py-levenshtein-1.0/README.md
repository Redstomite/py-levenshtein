#Py-Levenshtien

Python levenshtein project used to calculate the difference between two strings

download from command prompt using:
pip install git+git://github.com/Redstomite/py-levenshtein#egg=py-levenshtein
(pip needs to be installed first)

Algorithm:
https://en.wikipedia.org/wiki/Levenshtein_distance
